package ui;

import javax.swing.*;

public class Main extends JFrame {

    public static void main(String[] args) {
        new NewGameMenu();
    }
}
